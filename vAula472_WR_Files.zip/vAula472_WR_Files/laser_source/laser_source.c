/* ============================================================================

  Sensor Laser com LDR para uso Profissional
  Realiza leitura de sinal de 1.4kHz
  Na aus�ncia do sinal, detecta-se a interrup��o do feixe do laser e a
  sa�da GP0 � colocada em n�vel l�gico alto.

  MCU: PIC12F629
  Clock: 4MHz interno
  INTOSC IO GP4 & GP5, WDT OFF, PWT OFF, MCLRE OFF, Brown-out OFF
  Code Protection OFF, Data Code Protection OFF
  IDE: MikroC Pro For PIC v.7.1.0

  Autor: Dr. Eng. Wagner Rambo
  Data:  Fevereiro de 2023

============================================================================ */


// ============================================================================
// --- Interrup��es ---
void interrupt()
{
  if(INTCON&(1<<INTF))                         //borda de subida na interrup��o externa?
  {                                            //sim
    INTCON&=~(1<<INTF);                        //limpa flag da interrup��o externa
    TMR0  = 0x00;                              //reinicia o Timer0
    GPIO &= ~(1<<GP0);                         //desliga sa�da
  
  } //end if
  
  if(INTCON&(1<<T0IF))                         //overflow do Timer0? base de aprox. 8.2ms
  {                                            //sim
    INTCON&=~(1<<T0IF);                        //limpa flag do Timer0
    GPIO |= (1<<GP0);                          //liga sa�da
    
  } //end if T0IF

} //end interrupt


// ============================================================================
// --- Fun��o Principal ---
void main() 
{
  CMCON      = 0x07;                           //desabilita comparadores
  OPTION_REG = 0xC4;                           //prescaler 1:32 (Timer0 ligado), INT rising edge
  INTCON     = 0xB0;                           //interrup��o global, Timer0 e externa
  TRISIO &= ~(1<<GP0);                         //configura sa�da em GP0
  GPIO   &= ~(1<<GP0);                         //inicializa GP0 em LOW
            
  while(1);                                    //aguarda interrup��es

} //end main








































// ============================================================================
// --- Final do Programa ---